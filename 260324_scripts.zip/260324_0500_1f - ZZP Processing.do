use "G:\Arbeid\ZELFSTANDIGENMNDBEDRAGBUS\geconverteerde data\ZELFSTANDIGENMNDBEDRAGBUSV20201.DTA", clear
gen year = real(substr(aanvzelfstandigenmndbedrag,1,4))
keep if inrange(year,2010,2020)
egen po = tag(rinpersoon year)
by rinpersoon year, sort: egen earnings = sum(zelfstgeschatmndbedragfisc)
keep if po == 1
gen RINPERSOONMa = rinpersoon
gen RINPERSOONpa = rinpersoon
gen mumearnings = earnings
gen dadearnings = earnings
keep RINPERSOONMa RINPERSOONpa year mumearnings dadearnings
save "H:\ZZP.dta", replace