**2010 
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2010\140923 kinderopvang 2010V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2010
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2010.dta", replace

**2011
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2011\140923 kinderopvang 2011V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2011
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2011.dta", replace

**2012
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2012\Kinderopvang 2012V3.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2012
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2012.dta", replace

**2013
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2013\Kinderopvang 2013V3.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2013
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2013.dta", replace

**2014
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2014\Kinderopvang2014V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2014
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2014.dta", replace

**2015
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2015\Kinderopvang2015V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2015
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
keep if po == 1
keep Jaar RINPERSOON_KIND uren
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2015.dta", replace

**2016
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2016\Kinderopvang2016V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2016
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2016.dta", replace

**2017
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2017\Kinderopvang2017V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2017
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2017.dta", replace

**2018
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2018\Kinderopvang2018V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2018
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2018.dta", replace

**2019
import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2019\Kinderopvang2019V2.sav", clear
egen po = tag(RINPERSOON_KIND)
cap gen Jaar = 2019
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
by RINPERSOON_KIND, sort: egen uren_KO = sum(uren_opv) if srt_opv == 1
by RINPERSOON_KIND, sort: egen uren_GO = sum(uren_opv) if srt_opv == 3
keep if po == 1
keep Jaar RINPERSOON_KIND uren uren_KO uren_GO
rename RINPERSOON_KIND rinpersoon
rename Jaar year
sort rinpersoon
save "H:\ko_2019.dta", replace


