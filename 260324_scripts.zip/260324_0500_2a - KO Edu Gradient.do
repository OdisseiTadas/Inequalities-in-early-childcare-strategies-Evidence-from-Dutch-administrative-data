use "H:\CSsample.dta", clear

keep if inrange(birthyear,2006,2020)
gen age = year - birthyear
keep if inrange(age,0,4)

** ADD CHILDCARE DATA

forval x = 2010(1)2019 {
mer m:1 rinpersoon year using "H:\ko_`x'.dta", keep(1 3 4) nogen update
}

gen ko = 0
replace ko = 1 if inrange(uren,0,10000)
gen ko_int = 0
replace ko_int = 1 if inrange(uren,1000,10000)

** ADD PARENTS

mer m:1 rinpersoon using "H:\kindoud_sample.dta", keep(1 3) nogen update
keep if RINPERSOONMa != "" & RINPERSOONMa != "---------" & RINPERSOONpa != "" & RINPERSOONpa != "---------"


** ADD MATERNAL EDUCATION

mer m:1 rinpersoon using "H:\mumsed.dta", keep(1 3) nogen

gen oplnr = mumsed
mer m:1 oplnr using "K:\Utilities\Code_Listings\SSBreferentiebestanden\geconverteerde data\OPLEIDINGSNRREFV29.DTA", keep(1 3 4) keepusing(soi2006niveau) nogen

gen edu = .
replace edu = 0 if !missing(soi2006niveau)
replace edu = 1 if inlist(soi2006niveau,"51", "52", "53")
replace edu = 2 if inlist(soi2006niveau,"60", "70")

by edu year, sort: egen ko_av = mean(ko)
by edu year, sort: egen ko_av_int = mean(ko_int)
egen po = tag(edu year)

twoway line ko_av year if po == 1 & edu == 0 || line ko_av year if po == 1 & edu == 1 || line ko_av year if po == 1 & edu == 2, graphregion(color("white")) ytitle("Proportion of children aged 0-4", size(small)) xtitle("Year", size(small)) ylab(0(0.1)1, labsize(small)) xlab(2010(1)2019, labsize(small)) legend(label(1 "No Higher Education") label(2 "Bachelors") label(3 "Masters or higher") size(small) row(1) region(lstyle(none))) lcolor("dkgreen" "lime" "orange") title("Use of Formal Childcare", size(small))
graph export "H:\ko_edugrad.png", replace

twoway line ko_av_int year if po == 1 & edu == 0 || line ko_av_int year if po == 1 & edu == 1 || line ko_av_int year if po == 1 & edu == 2, graphregion(color("white")) ytitle("Proportion of children aged 0-4" , size(small)) xtitle("Year", size(small)) ylab(0(0.1)1, labsize(small)) xlab(2010(1)2019, labsize(small)) legend(label(1 "No Higher Education") label(2 "Bachelors") label(3 "Masters or higher") size(small) row(1) region(lstyle(none))) lcolor("dkgreen" "lime" "orange") title("Use of Formal Childcare for more than 2 days a week", size(small))
graph export "H:\ko_edugrad_intense.png", replace