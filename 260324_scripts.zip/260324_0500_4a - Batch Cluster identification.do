use "H:\analysis_file.dta", clear

gen mum30 = 0
replace mum30 = 1 if mumsuren25 == 5
gen ko5 = 0
replace ko5 = 1 if kouren25 == 5
by batch cl1_11, sort: egen mum_score = mean(mum30)
by batch cl1_11, sort: egen ko_score = mean(ko5)

egen po = tag(batch cl1_11)
by batch, sort: egen max_mum_score = max(mum_score)
by batch, sort: egen max_ko_score = max(ko_score)

egen bpo = tag(batch)
gen id_cl2 = cl1_11 if po == 1 & max_mum_score == mum_score & max_ko_score == ko_score

by batch, sort: egen batch_cl2 = max(id_cl2)

keep if cl1_11 == batch_cl2

keep RINPERSOONMa cl1_11
replace cl1_11 = 2
rename RINPERSOONMa rinpersoon

save "H:\classes_mum.dta", replace