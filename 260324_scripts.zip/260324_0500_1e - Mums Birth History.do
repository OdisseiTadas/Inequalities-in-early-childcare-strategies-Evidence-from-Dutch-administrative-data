use "G:\Bevolking\KINDOUDERTAB\geconverteerde bestanden\KINDOUDER2021TABV1.DTA", clear

keep if RINPERSOONMa != "" & RINPERSOONMa != "---------"
sort RINPERSOONMa

egen po = tag(rinpersoon)
drop if po == 0
drop po

mer 1:1 rinpersoon using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2019V1.DTA", keepusing(gbageboortejaar gbageboortemaand) nogen keep(1 3)
gen birthyear = real(gbageboortejaar)
drop if missing(birthyear)
by RINPERSOONMa, sort: egen rbirthorder = rank(birthyear), unique
gen cons = 1
by RINPERSOONMa, sort: egen births = sum(cons)
gen birthorder = (births + 1) - rbirthorder
drop if births > 10

preserve 
keep rinpersoon birthorder
save "H:\BirthOrder.dta", replace
restore

keep RINPERSOONMa birthyear birthorder
reshape wide birthyear, i(RINPERSOONMa) j(birthorder)

save "H:\MumBirthHistory.dta", replace