** MUMS
** 2010
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2010\SPOLISBUS2010V2.sav", clear
gen cm = ((2010 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2010.dta", replace

** 2011
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2011\SPOLISBUS2011V2.sav", clear
gen cm = ((2011 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2011.dta", replace

** 2012
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2012\SPOLISBUS2012V2.sav", clear
gen cm = ((2012 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2012.dta", replace

** 2013
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2013\SPOLISBUS2013V3.sav", clear
gen cm = ((2013 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2013.dta", replace

** 2014
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2014\SPOLISBUS 2014V1.sav", clear
gen cm = ((2014 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2014.dta", replace

** 2015
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2015\SPOLISBUS 2015V3.sav", clear
gen cm = ((2015 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2015.dta", replace

** 2016
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2016\SPOLISBUS2016V3.sav", clear
gen cm = ((2016 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2016.dta", replace

** 2017
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2017\SPOLISBUS2017V2.sav", clear
gen cm = ((2017 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2017.dta", replace

** 2018
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2018\SPOLISBUS2018V5.sav", clear
gen cm = ((2018 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2018.dta", replace

** 2019
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2019\SPOLISBUS2019V6.sav", clear
gen cm = ((2019 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\mums.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONMa
save "H:\mums_uren_2019.dta", replace

** DADS
** 2010
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2010\SPOLISBUS2010V2.sav", clear
gen cm = ((2010 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2010.dta", replace

** 2011
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2011\SPOLISBUS2011V2.sav", clear
gen cm = ((2011 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2011.dta", replace

** 2012
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2012\SPOLISBUS2012V2.sav", clear
gen cm = ((2012 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2012.dta", replace

** 2013
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2013\SPOLISBUS2013V3.sav", clear
gen cm = ((2013 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2013.dta", replace

** 2014
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2014\SPOLISBUS 2014V1.sav", clear
gen cm = ((2014 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2014.dta", replace

** 2015
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2015\SPOLISBUS 2015V3.sav", clear
gen cm = ((2015 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2015.dta", replace

** 2016
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2016\SPOLISBUS2016V3.sav", clear
gen cm = ((2016 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2016.dta", replace

** 2017
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2017\SPOLISBUS2017V2.sav", clear
gen cm = ((2017 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2017.dta", replace

** 2018
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2018\SPOLISBUS2018V5.sav", clear
gen cm = ((2018 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2018.dta", replace

** 2019
import spss RINPERSOON SDATUMAANVANGIKO SDATUMEINDEIKO SAANTVERLU SBASISLOON SCDINCINKVERM using "G:\Spolis\SPOLISBUS\2019\SPOLISBUS2019V6.sav", clear
gen cm = ((2019 - 2010)*12) + real(substr(SDATUMAANVANGIKO,5,2))
egen po = tag(RINPERSOON cm)
by RINPERSOON cm, sort: egen wrkuren = sum(SAANTVERLU)
gen wage = SBASISLOON/SAANTVERLU
by RINPERSOON cm, sort: egen wage_av = mean(wage)
gen leave_m = 1 if inlist(SCDINCINKVERM,"B", "O", "Z", "G", "K", "S")
by RINPERSOON cm, sort: egen leave = max(leave_m)
keep if po == 1
rename RINPERSOON rinpersoon
keep rinpersoon cm wrkuren wage_av leave
mer m:1 rinpersoon using "H:\dads.dta", keep(2 3) nogen
rename rinpersoon RINPERSOONpa
save "H:\dads_uren_2019.dta", replace