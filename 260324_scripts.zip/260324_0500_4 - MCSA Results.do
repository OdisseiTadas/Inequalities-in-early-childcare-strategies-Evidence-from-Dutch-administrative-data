use "H:\sqsample.dta", clear

**Preparing for Analysis - Adding Independent Variables

mer 1:1 rinpersoon using "H:\classes_test.dta", keep(1 3 4) nogen update

/*
forval i = 1(1)1500 {
mer 1:1 rinpersoon using "H:\classes_`i'.dta", keep(1 3 4) nogen update
}
*/
mer 1:1 rinpersoon using "H:\mumsed.dta", keep(1 3) nogen

gen oplnr = mumsed
mer m:1 oplnr using "H:\OPLEIDINGSNRREFV31.dta", keep(1 3 4) keepusing(soi2006niveau) nogen

gen edu = .
replace edu = 0 if !missing(soi2006niveau)
replace edu = 1 if inlist(soi2006niveau,"51", "52", "53")
replace edu = 2 if inlist(soi2006niveau,"60", "70")

recode mumsuren* dadsuren* (-2 = 7) (-1 = 8)

lab def mumsuren  1 "0 hours" 2 "1-10 hours" 3 "11-20 hours" 4 "20-30 hours" 5 "30-40 hours" 6 "40+ hours" 7 "ZZP" 8 "Leave"
lab def dadsuren  1 "0 hours" 2 "1-10 hours" 3 "11-20 hours" 4 "20-30 hours" 5 "30-40 hours" 6 "40+ hours" 7 "ZZP" 8 "Leave"
lab def kouren 1 "0 days" 2 "1 day" 3 "2 days" 4 "3 days" 5 "4 days" 5 "5 days"

lab val mumsuren* mumsuren
lab val dadsuren* dadsuren
lab val kouren* kouren


**** TIME CONSTANT VARIABLE CREATION *********

rename rinpersoon RINPERSOON
lab var RINPERSOON "Child's RIN"

** Mums Birth History

mer m:1 RINPERSOONMa using "H:\MumBirthHistory.dta", nogen keep(1 3)

** Dad YOB
rename RINPERSOONpa rinpersoon
mer m:1 rinpersoon using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2019V1.DTA", keepusing(gbageboortejaar) nogen keep(1 3)
gen dadsYOB = real(gbageboortejaar)
drop gbageboortejaar
rename rinpersoon RINPERSOONpa

** Mum YOB
rename RINPERSOONMa rinpersoon
mer m:1 rinpersoon using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2019V1.DTA", keepusing(gbageboortejaar) nogen keep(1 3)
gen mumsYOB = real(gbageboortejaar)
drop gbageboortejaar
rename rinpersoon RINPERSOONMa

** Birth Order
rename RINPERSOON rinpersoon
mer 1:1 rinpersoon using "H:\BirthOrder.dta", keepusing(birthorder) nogen keep(1 3)
replace birthorder = 3 if inrange(birthorder,3,10) 
rename rinpersoon RINPERSOON
save "H:\analysis_file_test.dta", replace

/*
keep RINPERSOONMa cl1_11
rename RINPERSOONMa rinpersoon 
save "H:\classes_mum.dta", replace
*/

