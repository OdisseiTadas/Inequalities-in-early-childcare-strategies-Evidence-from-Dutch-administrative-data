/*import spss RINPERSOONS_AANVRAGER RINPERSOON_AANVRAGER RINPERSOONS_PARTNER RINPERSOON_PARTNER RINPERSOONS_KIND RINPERSOON_KIND srt_opv uren_opv tar_opv using "G:\InkomenBestedingen\KINDEROPVANG\2019\Kinderopvang2019V2.sav", clear
egen po = tag(RINPERSOON_KIND)
by RINPERSOON_KIND, sort: egen uren = sum(uren_opv)
keep if po == 1
rename RINPERSOON_KIND rinpersoon
save "F:\CHILDCARESTRATEGIES\ko_2019_verify.dta", replace*/

use "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2010V1.DTA", clear
gen birthyear = real(gbageboortejaar)
keep if inrange(birthyear,2006,2010)
gen year = 2010

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2011V1.DTA", gen(add)
replace year = 2011 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2007,2011) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2012V1.DTA", gen(add)
replace year = 2012 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2008,2012) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2013V1.DTA", gen(add)
replace year = 2013 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2009,2013) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2014V1.DTA", gen(add)
replace year = 2014 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2010,2014) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2015V1.DTA", gen(add)
replace year = 2015 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2011,2015) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2016V1.DTA", gen(add)
replace year = 2016 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2012,2016) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2017V1.DTA", gen(add)
replace year = 2017 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2013,2017) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2018V1.DTA", gen(add)
replace year = 2018 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2014,2018) & add == 1)
drop add

append using "G:\Bevolking\GBAPERSOONKTAB\geconverteerde data\GBAPERSOONKTAB2019V1.DTA", gen(add)
replace year = 2019 if add == 1
replace birthyear = real(gbageboortejaar) if add == 1
keep if add != 1 | (inrange(birthyear,2015,2019) & add == 1)
drop add

save "H:\CSsample.dta", replace