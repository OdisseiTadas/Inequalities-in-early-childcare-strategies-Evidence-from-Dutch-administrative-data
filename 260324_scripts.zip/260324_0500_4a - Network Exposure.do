
insheet using "G:\Bevolking\BURENNETWERKTAB\BURENNETWERK2016TABV1.csv", clear names comma
rename v2 rinpersoon
mer m:1 rinpersoon using "H:\classes_mum.dta", keep(1 3) nogen
keep if !missing(cl1_11)
gen edge = "buren"
rename rinpersoon alter_rin
rename v1 rinpersoon
save "H:\buren_2016.dta", replace

insheet using "G:\Bevolking\FAMILIENETWERKTAB\FAMILIENETWERK2016TABV1 .csv", clear names comma
rename v2 rinpersoon
mer m:1 rinpersoon using "H:\classes_mum.dta", keep(1 3) nogen
keep if !missing(cl1_11)
gen edge = "familie"
rename rinpersoon alter_rin
rename v1 rinpersoon
save "H:\familie_2016.dta", replace


insheet using "G:\Bevolking\BURENNETWERKTAB\COLLEGANETWERK2016TABV1.csv", clear names comma
rename v2 rinpersoon
mer m:1 rinpersoon using "H:\classes_mum.dta", keep(1 3) nogen
keep if !missing(cl1_11)
gen edge = "collega"
rename rinpersoon alter_rin
rename v1 rinpersoon
save "H:\collega_2016.dta", replace

use "H:\analysis_file.dta"
append using "H:\buren_2016.dta"
append using "H:\familie_2016.dta" 

tab cl1_11, gen(class_)

forval x = 1(1)11 {
	local y = `x'
	by rinpersoon, sort: egen expo_`x' = count(class_`x')
}

egen po = tag(rinpersoon)
keep if po == 1
keep rinpersoon expo_*
rename rinpersoon RINPERSOONMa

save "H:\exposures.dta", replace