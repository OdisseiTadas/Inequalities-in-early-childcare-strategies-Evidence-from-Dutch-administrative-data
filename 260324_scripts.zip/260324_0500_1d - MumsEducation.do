cd "H:\"

use CSsample.dta, clear

egen po = tag(rinpersoon)

keep if po == 1
drop po

mer 1:m rinpersoon using GBASPINE, keep(1 3) keepusing(year) nogen
egen po = tag(rinpersoon)
keep if po == 1
keep rinpersoon year 
mer 1:1 rinpersoon using kindoud_sample, keepusing(RINPERSOONMa) keep(1 3) nogen


rename rinpersoon rinpersoonx
rename RINPERSOONMa RINPERSOON

gen str6 mumsed = ""

forval year = 2010(1)2019 {
	mer m:m RINPERSOON using "H:\HDIPLOMAREGTAB`year'.dta", keepusing(OPLNRDIPLREG) keep(1 3) nogen
	egen po = tag(rinpersoonx)
	keep if po == 1
	drop po
	rename OPLNRDIPLREG OPLNRDIPLREG_`year'
}

replace mumsed = OPLNRDIPLREG_2010 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "")
replace mumsed = OPLNRDIPLREG_2011 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2012 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2013 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2014 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2015 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2016 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2017 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2018 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")
replace mumsed = OPLNRDIPLREG_2019 if (OPLNRDIPLREG_2010 != "------" | OPLNRDIPLREG_2010 != "") & (mumsed == "" | mumsed == "------")

replace mumsed = OPLNRDIPLREG_2019 if mumsed == ""

keep rinpersoonx mumsed
rename rinpersoonx rinpersoon

save "H:\mumsed.dta", replace


