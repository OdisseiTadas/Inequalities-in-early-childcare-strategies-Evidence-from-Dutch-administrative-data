use "H:\GBASPINE.dta", clear 

keep rinpersoon RINPERSOONMa RINPERSOONpa age_m cm mumsuren dadsuren kouren uren uren_KO uren_GO mum_wage dads_wage dadleave mumleave mumearnings dadearnings
rename (mumsuren dadsuren kouren) (mumsuren_x dadsuren_x kouren_x)

/*
** LISS VALIDATION

mer m:1 RINPERSOONMa using "H:\LISS_link.dta", keep(1 3) nogen
rename Nomem_encr_crypt id_crypt
mer m:1 RINPERSOONpa using "H:\LISS_link.dta", keep(1 3 4) nogen
replace id_crypt = Nomem_encr_crypt if missing(id_crypt)
drop Nomem_encr_crypt
mer m:1 id_crypt cm using "H:\LISS_Childcare.dta", keep(1 3) nogen
*/
**histogram kouren_x if inrange(kouren_x, 0, 200), percent color(blue) graphregion(color(white)) xtitle("Childcare hours per month") ytitle("Percent")
**graph export "H:\childcare_hist.png", replace

egen mumsuren = cut(mumsuren_x), at(0, 1, 40, 80, 120, 160, 1000) icodes
egen dadsuren = cut(dadsuren_x), at(0, 1, 40, 80, 120, 160, 1000) icodes
egen kouren = cut(kouren_x), at(0, 1, 20, 45, 55, 69, 1000) icodes

replace mumsuren = -1 if mumleave == 1
replace dadsuren = -1 if dadleave == 1
replace mumsuren = -2 if !missing(mumearnings) & mumsuren == 0 
replace dadsuren = -2 if !missing(dadearnings) & dadsuren == 0

/*
corr childcarehrs kouren_x if inrange(kouren_x, 0, 1000) & inrange(childcarehrs, 0, 1000)
scatter childcarehrs kouren_x if inrange(kouren_x, 0, 1000) & inrange(childcarehrs, 0, 1000)
*/

gen cons = 1
by rinpersoon, sort: egen _obs = sum(cons)
keep if inlist(_obs,48)

drop cons _obs kouren_x mumsuren_x dadsuren_x mumleave dadleave mumearnings dadearnings
reshape wide mumsuren dadsuren kouren mum_wage dads_wage uren uren_GO uren_KO cm, i(rinpersoon) j(age_m)

foreach x in kouren dadsuren mumsuren {
	forval y = 1 (1) 47 {
		drop if `x'`y' == .
	}
}

**splitsample, gen(batch) nsplit(1500)
sample 20
save "H:\sqsample.dta", replace

/* 
forval b = 1(1)1500 { 
	foreach x in mumsuren dadsuren kouren {
		use  "H:\sqsample.dta", clear
		keep rinpersoon `x'* batch
		keep if batch == `b'
		save "H:\sqchan_`x'_`b'.dta", replace
}
}
*/



foreach x in mumsuren dadsuren kouren {
use  "H:\sqsample.dta", clear
keep rinpersoon `x'* 
save "H:\sqchan_`x'_test.dta", replace
}

