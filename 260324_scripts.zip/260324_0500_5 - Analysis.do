use "H:\analysis_file_test.dta", clear

replace edu = edu + 1
replace edu = 0 if edu == .

lab def edu 0 "No Record" 1 "High School" 2 "Bachelors" 3 "Masters or higher"
lab val edu edu

mer 1:1 RINPERSOON using "H:\MigrantVar.dta", keep (1 3)
gen migrant = 0
replace migrant = 1 if EUmigration == 1 | nonEUmigration == 1

** Class Prediction

**lab def cl1_11 1 "" 2 "" 3 "" 4 "" 5 "" 6 "" 7 "" 8 "" 9 "" 10 "" 11 ""
**lab val cl1_11 cl1_11

chronogram kouren*, by(cl1_12, graphregion(color("white"))) prop color(ltblue eltblue ebblue emidblue edkblue)  xtitle("Month", size(small)) legend(size(small) row(1) region(lstyle(none)))
graph export "H:\kouren_12.png", replace
chronogram mumsuren*, by(cl1_12, graphregion(color("white"))) prop color("254 229 217" "252 187 161" "252 146 114" "251 106 74" "222 45 38" "165 15 21" "197 27 125" "233 163 201")  xtitle("Month", size(small)) legend(size(small) row(2) region(lstyle(none)))
graph export "H:\mumsuren_12.png", replace
chronogram dadsuren*, by(cl1_12, graphregion(color("white"))) prop color("237 248 233" "199 233 192" "161 217 155" "116 196 118" "49 163 84" "0 109 44" "118 42 131" "175 141 195") xtitle("Month", size(small)) legend(size(small) row(2) region(lstyle(none)))
graph export "H:\dadsuren_12.png", replace

/* Green 0 128 0 Yellow 255 210 0  */


reshape long mumsuren dadsuren kouren cm uren uren_KO uren_GO wage_av childcarehrs, i(RINPERSOON) j(obs)


**** TIME VARYING VARIABLE CREATION **********

** Year 

gen year = floor((cm-1)/12) + 2010
lab var year "Year of Obs"

** Age of Child 

gen age = obs
lab var age "Age (Months) at obs"
gen agey = floor(age/12)

** Age of Mother & Father

gen mumsage = year - mumsYOB
lab var mumsage "Mums age at birth"
replace mumsage = 52 if inrange(mumsage, 52, 100)

gen dadsage = year - dadsYOB
lab var dadsage "Dads age at birth"
replace mumsage = 72 if inrange(mumsage, 72, 100)

** Maternal education 

lab var edu "Maternal Education Level [Fixed]"

** Age of Youngest Child

forval x = 1(1)10 {
gen childage_`x' = birthyear`x' - year
replace childage_`x' = . if !inrange(childage_`x', 0 , 12)
}

gen ageyoung = agey
forval x = 1(1)10 {
replace ageyoung =  childage_`x' if childage_`x' < ageyoung
}

gen ageyounger = ageyoung if age == 48
by RINPERSOON, sort: egen ageyoungest = max(ageyounger)
lab var ageyoungest "Youngest child of the mother at Obs"

gen followed = 0
replace followed = 1 if ageyoungest < 4

gen preceded = 0 
forval x = 1(1)10 {
replace preceded = 1 if age == 1 & birthyear`x' < (year - 1)
}

** Number of Siblings

gen sibling = 0 
forval x = 1(1)10 {
replace sibling = sibling + 1 if inrange(birthyear`x', 1900 , year)
}
by RINPERSOON, sort: egen siblings = max(sibling)
lab var siblings "Max number of Maternal Siblings during Obs"

gen under4 = 0 
forval x = 1(1)10 {
replace under4 = under4 + 1 if inrange(childage_`x', 0 , 4)
}
by RINPERSOON, sort: egen under4s = max(under4)
lab var under4s "Max Number of Maternal Siblings under 4 during Obs"

**Adding Income
gen rinpersoon = RINPERSOONpa
forval x = 2010(1)2019 {
mer m:1 rinpersoon year using "H:\INPATAB`x'.dta", keep(1 3 4) nogen update
}
drop rinpersoon
replace INPP100PPERS = .5 if missing(INPP100PPERS) | INPP100PPERS < 1
gen incper = 0
replace incper = 1 if inrange(INPP100PPERS,1,40)
replace incper = 2 if inrange(INPP100PPERS,75,100)


** Municipality

drop ageyoung ageyounger under4 sibling
keep if age == 1

mer 1:1 RINPERSOON using "H:\Address.dta", keep(1 3) nogen
mer m:1 RINOBJECTNUMMER using "H:\gemeente.dta", keep(1 3) keepusing(gem2019) nogen
encode gem2019, gen(gemeente)

**** CREATE DESCRIPTIVE TABLES **********
**Continuous = year, age, birthorder, ageyoungest, siblings, under4s, mumsage, dadsage 

**Discrete = kouren, mumsuren, dadsuren, edu

cap log close
log using "H:\Analysis.log", replace

tabstat year siblings followed preceded mumsage migrant, statistics(mean sd p25 p75) columns(statistics)

tab cl1_12

tab kouren cl1_12, row nof
tab mumsuren cl1_12, row nof
tab dadsuren cl1_12, row nof
tab edu cl1_12, row nof

mlogit cl1_12 i.edu i.preceded i.followed c.mumsage i.incper i.migrant

graph drop _all

forval x = 1(1)12 {
margins edu, atmeans predict(outcome(`x'))
marginsplot, name(cl_`x') graphregion(color(white)) recast(scatter) ylab(0(0.1)0.5) ytitle("Probability of group membership")
}

log close

