clear
use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2011TABV2.DTA", clear
keep rinpersoon INPP100PPERS
gen year = 2010
save "H:\INPATAB2010.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2011TABV2.DTA", clear
keep rinpersoon INPP100PPERS
gen year = 2011
save "H:\INPATAB2011.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2012TABV2.DTA", clear 
keep rinpersoon INPP100PPERS
gen year = 2012
save "H:\INPATAB2012.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2013TABV2.DTA", clear 
keep rinpersoon INPP100PPERS
gen year = 2013
save "H:\INPATAB2013.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2014TABV2.DTA", clear
keep rinpersoon INPP100PPERS
gen year = 2014
save "H:\INPATAB2014.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2015TABV2.DTA", clear 
keep rinpersoon INPP100PPERS
gen year = 2015
save "H:\INPATAB2015.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2016TABV3.DTA", clear
rename RINPERSOON rinpersoon
keep rinpersoon INPP100PPERS
gen year = 2016
save "H:\INPATAB2016.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2017TABV3.DTA", clear
rename RINPERSOON rinpersoon
keep rinpersoon INPP100PPERS
gen year = 2017
save "H:\INPATAB2017.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2018TABV2.DTA", clear
keep rinpersoon INPP100PPERS
gen year = 2018
save "H:\INPATAB2018.dta", replace

use "G:\InkomenBestedingen\INPATAB\geconverteerde data\INPA2019TABV2.DTA", clear
keep rinpersoon INPP100PPERS
gen year = 2019
save "H:\INPATAB2019.dta", replace

