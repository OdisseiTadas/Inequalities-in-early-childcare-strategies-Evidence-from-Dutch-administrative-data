library("TraMineR")
library("readstata13")

path <- paste0("H:/classes_test.dta")
clus <- read.dta13(path)
clus <- clus[!duplicated(clus$rinpersoon),]

mumpath <- paste0("H:/sqchan_mumsuren_test.dta")
dadpath <- paste0("H:/sqchan_dadsuren_test.dta")
kopath <- paste0("H:/sqchan_kouren_test.dta")

mumsuren <- read.dta13(mumpath)
dadsuren <- read.dta13(dadpath)
kouren <- read.dta13(kopath) 

channel_mumsuren <- seqdef(mumsuren, 2:49, informat = "STS")
channel_dadsuren <- seqdef(dadsuren, 2:49, informat = "STS")
channel_kouren <- seqdef(kouren, 2:49, informat = "STS")



# channel_mumsuren <- merge(channel_mumsuren, clus, by = "rinpersoon", all = TRUE)
# channel_dadsuren <- merge(channel_dadsuren, clus, by = "rinpersoon", all = TRUE)
# channel_kouren <- merge(channel_kouren, clus, by = "rinpersoon", all = TRUE)
# 
# table(kouren$cl1_12)
# 
# tapply(seqlength(seqdss(channel_kouren)), channel_kouren$cl1_12, mean)
# tapply(seqlength(seqdss(channel_mumsuren)), channel_mumsuren$cl1_12, mean)
# tapply(seqlength(seqdss(channel_dadsuren)), channel_dadsuren$cl1_12, mean)
# 
# tapply(seqient(channel_kouren), channel_kouren$cl1_12, mean)
# tapply(seqient(channel_mumsuren), channel_mumsuren$cl1_12, mean)
# tapply(seqient(channel_dadsuren), channel_dadsuren$cl1_12, mean)
# 
# tapply(seqST(channel_kouren), channel_kouren$cl1_12, mean)
# tapply(seqST(channel_mumsuren), channel_mumsuren$cl1_12, mean)
# tapply(seqST(channel_dadsuren), channel_dadsuren$cl1_12, mean)