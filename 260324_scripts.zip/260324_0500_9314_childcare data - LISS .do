** Childcare usage for all households between 2010 & 2019 in LISS with children aged 0-5
** Variables: year, id, n_kids, ageyoungest, mumwrkhrs, dadwrkhrs, childcarehrs

foreach z in cf19l cf18k cf17j cf16i cf15h {

use "/Users/temery/Desktop/Childcare Strategies/`z'_EN_1.0p.dta", clear

gen year = floor((`z'_m/100))
gen month = `z'_m - (year*100)

rename `z'455 n_kids
rename nomem_encr id

gen kids04 = 0

forval x = 1(1)14 {
	local i = 55 + `x'
	local yearlo = year - 4
	local yearhi = year
	replace kids04 = 1 if inrange(`z'4`i',`yearlo',`yearhi')
}

gen childcarepd = `z'249


keep if !missing(`z'249) | !missing(`z'338) | !missing(`z'380)
gen childcarehrs = 0 
replace childcarehrs = childcarehrs + `z'250 if !missing(`z'250)
replace childcarehrs = (childcarepd*4) if childcarepd > 0 & !missing(childcarehrs)
replace childcarehrs = 0 if `z'327 == 0 & `z'328 == 0 & `z'329 == 0 & `z'330 == 0 & `z'331 == 0 & `z'332 == 0 & `z'333 == 0 & `z'334 == 0 & `z'335

lab var year "Year"
lab var month "Month"
lab var childcarehrs "Weekly hours of childcare"
lab var kids04 "Children aged 0-4 (Y/N)"


keep year month id n_kids childcarehrs kids04
save "/Users/temery/Desktop/Childcare Strategies/`z'_trim.dta", replace
}


foreach z in cf14g cf13f cf12e cf11d cf10c cf09b cf08a {

use "/Users/temery/Desktop/Childcare Strategies/`z'_EN_1.0p.dta", clear

gen year = floor((`z'_m/100))
gen month = `z'_m - (year*100)

rename `z'036 n_kids
rename nomem_encr id

gen yearyoung = . 

gen kids04 = 0

forval x = 1(1)14 {
	local i = 36 + `x'
	local yearlo = year - 4
	local yearhi = year
	replace kids04 = 1 if inrange(`z'0`i',`yearlo',`yearhi')
}

gen childcarepd = `z'249

keep if !missing(`z'249) | !missing(`z'338) | !missing(`z'380)
gen childcarehrs = 0
replace childcarehrs = childcarehrs + `z'250 if !missing(`z'250)
replace childcarehrs = (childcarepd*4) if childcarepd > 0 & !missing(childcarehrs)
replace childcarehrs = 0 if `z'327 == 0 & `z'328 == 0 & `z'329 == 0 & `z'330 == 0 & `z'331 == 0 & `z'332 == 0 & `z'333 == 0 & `z'334 == 0 & `z'335


lab var year "Year"
lab var month "Month"
lab var childcarehrs "Weekly hours of childcare"
lab var kids04 "Children aged 0-4 (Y/N)"


keep year month id n_kids childcarehrs kids04
save "/Users/temery/Desktop/Childcare Strategies/`z'_trim.dta", replace
}

foreach x in cf19l cf18k cf17j cf16i cf15h cf14g cf13f cf12e cf11d cf10c cf09b {
	append using "/Users/temery/Desktop/Childcare Strategies/`x'_trim.dta"
}

keep if kids04 == 1

save "/Users/temery/Desktop/Childcare Strategies/LISS_Childcare.dta", replace
