
import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2010V2.SAV", clear
save "H:\HDIPLOMAREGTAB2010.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2011V3.SAV", clear
save "H:\HDIPLOMAREGTAB2011.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2012V2.SAV", clear
save "H:\HDIPLOMAREGTAB2012.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2013V2.SAV", clear
save "H:\HDIPLOMAREGTAB2013.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2014V3.SAV", clear
save "H:\HDIPLOMAREGTAB2014.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2015V3.SAV", clear
save "H:\HDIPLOMAREGTAB2015.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2016V4.SAV", clear
save "H:\HDIPLOMAREGTAB2016.dta", replace

import spss using "G:\Onderwijs\HDIPLOMAREGTAB\HDIPLOMAREGTAB2017V4.SAV", clear
save "H:\HDIPLOMAREGTAB2017.dta", replace

import delimited using "H:\Hdiploma_18.csv", clear delim(";")
rename (rinpersoon oplnrdiplreg) (RINPERSOON OPLNRDIPLREG)
save "H:\HDIPLOMAREGTAB2018.dta", replace

import delimited using "H:\Hdiploma_19.csv", clear delim(";")
rename (rinpersoon oplnrdiplreg) (RINPERSOON OPLNRDIPLREG)
save "H:\HDIPLOMAREGTAB2019.dta", replace



