library("TraMineR")
library("readstata13")
library("cluster")
library("WeightedCluster")
library("seqHMM")
library("foreign")

# Training the Clustering Algortithm

mumpath <- paste0("H:/sqchan_mumsuren_train", ".dta")
dadpath <- paste0("H:/sqchan_mumsuren_train", ".dta")
kopath <- paste0("H:/sqchan_mumsuren_train", ".dta")

mumsuren <- read.dta13(mumpath)
dadsuren <- read.dta13(dadpath)
kouren <- read.dta13(kopath)

channel_mumsuren <- seqdef(mumsuren, 2:49, informat = "STS")
channel_dadsuren <- seqdef(dadsuren, 2:49, informat = "STS")
channel_kouren <- seqdef(kouren, 2:49, informat = "STS")

dist.sqmen <- seqdistmc(channels = list(channel_mumsuren, channel_dadsuren, channel_kouren), method = "DHD", with.missing=TRUE)  
cluster1 <- agnes(dist.sqmen, diss = TRUE, method = "ward")

kouren$cl1.3 <-cutree(cluster1, k = 3)
kouren$cl1.4 <-cutree(cluster1, k = 4)
kouren$cl1.5 <-cutree(cluster1, k = 5)
kouren$cl1.6 <-cutree(cluster1, k = 6)
kouren$cl1.7 <-cutree(cluster1, k = 7)
kouren$cl1.8 <-cutree(cluster1, k = 8)
kouren$cl1.9 <-cutree(cluster1, k = 9)
kouren$cl1.10 <-cutree(cluster1, k = 10)
kouren$cl1.11 <-cutree(cluster1, k = 11)
kouren$cl1.12 <-cutree(cluster1, k = 12)
kouren$cl1.13 <-cutree(cluster1, k = 13)
kouren$cl1.14 <-cutree(cluster1, k = 14)
kouren$cl1.15 <-cutree(cluster1, k = 15)
kouren$cl1.16 <-cutree(cluster1, k = 16)
kouren$cl1.17 <-cutree(cluster1, k = 17)
kouren$cl1.18 <-cutree(cluster1, k = 18)
kouren$cl1.19 <-cutree(cluster1, k = 19)
kouren$cl1.20 <-cutree(cluster1, k = 20)


# Assigning the full set to clusters


mumpath <- paste0("H:/sqchan_mumsuren_full", ".dta")
dadpath <- paste0("H:/sqchan_mumsuren_full", ".dta")
kopath <- paste0("H:/sqchan_mumsuren_full", ".dta")

mumsuren <- read.dta13(mumpath)
dadsuren <- read.dta13(dadpath)
kouren <- read.dta13(kopath)

channel_mumsuren <- seqdef(mumsuren, 2:49, informat = "STS")
channel_dadsuren <- seqdef(dadsuren, 2:49, informat = "STS")
channel_kouren <- seqdef(kouren, 2:49, informat = "STS")

dist.sqmen <- seqdistmc(channels = list(channel_mumsuren, channel_dadsuren, channel_kouren), method = "DHD", with.missing=TRUE)  



filepath <- paste0("H:/classes_learnt.dta")
write.dta(kouren, filepath)
