library("TraMineR")
library("readstata13")
library("cluster")
library("WeightedCluster")
library("seqHMM")
library("foreign")

batch <- c(1:1500)
  
# (agnesRange <- wcKMedRange(dist.sqmen, 2:20))
# pdf('agnesplot.pdf', width = 6, height = 5)
# 
# plot(agnesRange, stat = c("ASW", "HG", "PBC" ), lwd = 5)
# dev.off()
# 
# pdf('MCSAtree.pdf', width = 20, height = 30)
# plot(cluster1, which.plot = 2)
# dev.off()
  
for (i in batch) 
  {
    mumpath <- paste0("H:/sqchan_mumsuren_", i ,".dta")
    dadpath <- paste0("H:/sqchan_mumsuren_", i ,".dta")
    kopath <- paste0("H:/sqchan_mumsuren_", i ,".dta")
    
    mumsuren <- read.dta13(mumpath)
    dadsuren <- read.dta13(dadpath)
    kouren <- read.dta13(kopath)
    
    channel_mumsuren <- seqdef(mumsuren, 2:49, informat = "STS")
    channel_dadsuren <- seqdef(dadsuren, 2:49, informat = "STS")
    channel_kouren <- seqdef(kouren, 2:49, informat = "STS")
    
    dist.sqmen <- seqdistmc(channels = list(channel_mumsuren, channel_dadsuren, channel_kouren), method = "DHD", with.missing=TRUE)  
    cluster1 <- agnes(dist.sqmen, diss = TRUE, method = "ward")
  
    kouren$cl1.3 <-cutree(cluster1, k = 3)
    kouren$cl1.4 <-cutree(cluster1, k = 4)
    kouren$cl1.5 <-cutree(cluster1, k = 5)
    kouren$cl1.6 <-cutree(cluster1, k = 6)
    kouren$cl1.7 <-cutree(cluster1, k = 7)
    kouren$cl1.8 <-cutree(cluster1, k = 8)
    kouren$cl1.9 <-cutree(cluster1, k = 9)
    kouren$cl1.10 <-cutree(cluster1, k = 10)
    kouren$cl1.11 <-cutree(cluster1, k = 11)
    kouren$cl1.12 <-cutree(cluster1, k = 12)
  
  filepath <- paste0("H:/classes_", i ,".dta")
  write.dta(kouren, filepath)
}