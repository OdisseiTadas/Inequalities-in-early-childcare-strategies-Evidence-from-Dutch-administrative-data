library(data.table)
library("foreign")

mumsuren <- read.dta13("H:\classes_mum.dta")
fam_net <- fread("G:/Bevolking/FAMILIENETWERKTAB/FAMILIENETWERK2016TABV1.csv")



