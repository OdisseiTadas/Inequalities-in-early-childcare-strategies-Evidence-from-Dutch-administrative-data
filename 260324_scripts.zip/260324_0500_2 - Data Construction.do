use "H:\CSsample.dta", clear

keep if inrange(birthyear,2006,2020)
gen birthmonth = real(gbageboortemaand)
gen birthcm = ((birthyear-2010)*12) + birthmonth
lab var birthcm "Birth Calendar Month"
gen cons = 1
by rinpersoon, sort: egen obs = sum(cons)
keep if obs > 3 
keep if year == birthyear
keep rinpersoon gbageslacht gbageboortejaar gbageboortemaand gbageboortedag birthcm birthyear birthmonth

** ADD PARENTS

mer m:1 rinpersoon using "H:\kindoud_sample.dta", keep(1 3) nogen update
keep if RINPERSOONMa != "" & RINPERSOONMa != "---------" & RINPERSOONpa != "" & RINPERSOONpa != "---------"

**SAMPLE FOR ANALYSIS

sample 25000, count
egen po = tag(rinpersoon)
keep if po == 1
drop po

** Create Long Format
expand 120

** Create Calendar Months (cm)
by rinpersoon, sort: egen cm = rank(birthcm), unique

** Create Age at CM & keep only those aged 0 to 5 in 2010 to 2020.
gen age_m = cm - birthcm + 1
keep if inrange(age_m,1,48)

gen year = 2010 if inrange(cm,1,12)
replace year = 2011 if inrange(cm,13,24)
replace year = 2012 if inrange(cm,25,36)
replace year = 2013 if inrange(cm,37,48)
replace year = 2014 if inrange(cm,49,60)
replace year = 2015 if inrange(cm,61,72)
replace year = 2016 if inrange(cm,73,84)
replace year = 2017 if inrange(cm,85,96)
replace year = 2018 if inrange(cm,97,108)
replace year = 2019 if inrange(cm,109,120)

**Adding ZZP
mer m:1 RINPERSOONMa year using "H:\ZZP.dta", keep(1 3 4) nogen update keepusing(mumearnings)
mer m:1 RINPERSOONpa year using "H:\ZZP.dta", keep(1 3 4) nogen update keepusing(dadearnings)

** Adding the Kinderopvang hours

forval x = 2010(1)2019 {
mer m:1 rinpersoon year using "H:\ko_`x'.dta", keep(1 3 4) nogen update
}

gen wrkuren = .
gen wage_av = .
forval x = 2010(1)2019 {
mer m:1 RINPERSOONMa cm using "H:\mums_uren_`x'.dta", keep(1 3 4) nogen update
}
rename wrkuren mumsuren
rename wage_av mum_wage
rename leave mumleave

gen wrkuren = .
gen wage_av = .
forval x = 2010(1)2019 {
mer m:1 RINPERSOONpa cm using "H:\dads_uren_`x'.dta", keep(1 3 4) nogen update
}
rename wrkuren dadsuren
rename wage_av dads_wage
rename leave dadleave

foreach x in mumsuren dadsuren uren {
	replace `x' = 0 if `x' == .
}

by rinpersoon year, sort: egen mumsuren_y = sum(mumsuren)
by rinpersoon year, sort: egen dadsuren_y = sum(dadsuren)

egen po_y = tag(rinpersoon year)

gen zzp_mum = 0
replace zzp_mum = 1 if !missing(mumearnings)
gen zzp_dad = 0
replace zzp_dad = 1 if !missing(dadearnings)
replace mumleave = 0 if missing(mumleave)
replace dadleave = 0 if missing(dadleave)

reg uren dadsuren_y mumsuren_y zzp_mum zzp_dad mumleave dadleave if po_y == 1, cluster(rinpersoon)
gen kouren = _b[dadsuren_y]*dadsuren + _b[mumsuren_y]*mumsuren + (_b[_cons]/12)
replace kouren = 0 if uren == 0
replace kouren = 0 if mumsuren == 0 & dadsuren == 0 

reg uren_KO dadsuren_y mumsuren_y if po_y == 1, cluster(rinpersoon)
gen kouren_KO = _b[dadsuren_y]*dadsuren + _b[mumsuren_y]*mumsuren + (_b[_cons]/12)
replace kouren_KO = 0 if uren == 0
replace kouren_KO = 0 if mumsuren == 0 & dadsuren == 0 

reg uren_GO dadsuren_y mumsuren_y if po_y == 1, cluster(rinpersoon)
gen kouren_GO = _b[dadsuren_y]*dadsuren + _b[mumsuren_y]*mumsuren + (_b[_cons]/12)
replace kouren_GO = 0 if uren == 0
replace kouren_GO = 0 if mumsuren == 0 & dadsuren == 0 

gen kouren_2 = uren * (((mumsuren * 5) + dadsuren) / ((mumsuren_y * 5) + dadsuren_y))
replace kouren_2 = 0 if mumsuren_y == 0 & dadsuren_y == 0
replace kouren_2 = (uren / 12) if mumsuren_y == 0 & dadsuren_y == 0 & uren != 0
replace kouren_2 = 300 if kouren_2 > 300 & !missing(kouren_2)

save "H:\GBASPINE.dta", replace


